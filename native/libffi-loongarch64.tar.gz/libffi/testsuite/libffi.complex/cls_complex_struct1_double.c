/* { dg-do run } */

#include "complex_defs_double.inc"
#include "cls_complex_struct1.inc"
