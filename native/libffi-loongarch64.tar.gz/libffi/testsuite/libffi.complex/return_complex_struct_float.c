/* { dg-do run } */

#include "complex_defs_float.inc"
#include "return_complex_struct.inc"
