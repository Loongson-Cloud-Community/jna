/* { dg-do run } */

#include "complex_defs_float.inc"
#include "test_complex_non_va.inc"

