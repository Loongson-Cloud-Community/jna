/* { dg-do run } */

#include "complex_defs_float.inc"
#include "test_complex_va1.inc"

