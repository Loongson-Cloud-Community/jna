/* { dg-do run } */

#include "complex_defs_double.inc"
#include "return_complex_struct.inc"
