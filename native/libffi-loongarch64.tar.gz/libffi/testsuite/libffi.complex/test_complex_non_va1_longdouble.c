/* { dg-do run } */

#include "complex_defs_longdouble.inc"
#include "test_complex_non_va1.inc"

