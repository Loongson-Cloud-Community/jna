/* { dg-do run } */

#include "complex_defs_float.inc"
#include "cls_complex_struct1.inc"
