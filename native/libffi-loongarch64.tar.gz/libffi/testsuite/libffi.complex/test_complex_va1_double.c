/* { dg-do run } */

#include "complex_defs_double.inc"
#include "test_complex_va1.inc"

